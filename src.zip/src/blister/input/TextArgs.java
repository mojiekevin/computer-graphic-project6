package blister.input;

import ext.csharp.EventArgs;

public class TextArgs extends EventArgs {
	public String Text;
}
